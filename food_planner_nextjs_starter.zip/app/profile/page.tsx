"use client";

import Nav from "@/components/Nav";
import { useApp } from "@/lib/store";
import { useEffect, useState } from "react";
import { initTelegram } from "@/lib/telegram";
import { Preset } from "@/lib/types";

export default function ProfilePage(){
  const { targets, setTargets, presets, addPreset, removePreset } = useApp();
  const [form, setForm] = useState({ kcal: targets.kcal, p: targets.p, f: targets.f, c: targets.c });
  const [np, setNP] = useState({ name:"", type:"Завтрак", kcal:"", p:"", f:"", c:"" });

  useEffect(() => { initTelegram(); }, []);

  function saveTargets(){
    const next = {
      kcal: Number(form.kcal)||0,
      p: Number(form.p)||0,
      f: Number(form.f)||0,
      c: Number(form.c)||0,
    };
    setTargets(next);
    alert("Цели сохранены");
  }

  function addNewPreset(){
    if(!np.name || !np.kcal) { alert("Укажи название и калории"); return; }
    const p: Preset = {
      id: Math.random().toString(36).slice(2,9),
      name: np.name.trim(),
      type: np.type as any,
      kcal: Number(np.kcal)||0,
      p: Number(np.p)||0,
      f: Number(np.f)||0,
      c: Number(np.c)||0,
    };
    addPreset(p);
    setNP({ name:"", type:"Завтрак", kcal:"", p:"", f:"", c:"" });
  }

  return (
    <div>
      <Nav />
      <div className="max-w-5xl mx-auto p-4 space-y-4">
        <div className="card">
          <h2 className="mb-3">Цели</h2>
          <div className="grid md:grid-cols-4 gap-3">
            <div><div className="small mb-1">Калории/день</div><input type="number" value={form.kcal} onChange={e=>setForm({...form, kcal: Number(e.target.value)})} /></div>
            <div><div className="small mb-1">Белки</div><input type="number" value={form.p} onChange={e=>setForm({...form, p: Number(e.target.value)})} /></div>
            <div><div className="small mb-1">Жиры</div><input type="number" value={form.f} onChange={e=>setForm({...form, f: Number(e.target.value)})} /></div>
            <div><div className="small mb-1">Углеводы</div><input type="number" value={form.c} onChange={e=>setForm({...form, c: Number(e.target.value)})} /></div>
          </div>
          <div className="mt-3"><button className="btn-primary" onClick={saveTargets}>Сохранить цели</button></div>
        </div>

        <div className="card">
          <h2 className="mb-3">Добавить пресет</h2>
          <div className="grid md:grid-cols-6 gap-3">
            <input placeholder="Название" value={np.name} onChange={e=>setNP({...np, name:e.target.value})} />
            <select value={np.type} onChange={e=>setNP({...np, type:e.target.value})}>
              <option>Завтрак</option>
              <option>Обед</option>
              <option>Ужин</option>
              <option>Перекус</option>
            </select>
            <input placeholder="ккал" type="number" value={np.kcal} onChange={e=>setNP({...np, kcal:e.target.value})} />
            <input placeholder="Б" type="number" value={np.p} onChange={e=>setNP({...np, p:e.target.value})} />
            <input placeholder="Ж" type="number" value={np.f} onChange={e=>setNP({...np, f:e.target.value})} />
            <input placeholder="У" type="number" value={np.c} onChange={e=>setNP({...np, c:e.target.value})} />
          </div>
          <div className="mt-3"><button className="btn-primary" onClick={addNewPreset}>Добавить</button></div>
        </div>

        <div className="card">
          <h2 className="mb-3">Мои пресеты</h2>
          <div className="grid md:grid-cols-2 gap-2">
            {presets.map(p => (
              <div key={p.id} className="bg-slate-900/50 border border-slate-700/50 rounded-xl p-3">
                <div className="font-semibold">{p.name}</div>
                <div className="small mb-2">{p.type} • ккал:{Math.round(p.kcal)} Б:{p.p.toFixed(1)} Ж:{p.f.toFixed(1)} У:{p.c.toFixed(1)}</div>
                <button className="btn-ghost" onClick={()=> removePreset(p.id)}>Удалить</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
