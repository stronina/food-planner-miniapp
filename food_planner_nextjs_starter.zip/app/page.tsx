"use client";

import Nav from "@/components/Nav";
import { useEffect, useMemo, useState } from "react";
import { useApp } from "@/lib/store";
import { getPresetById, fmt } from "@/lib/helpers";
import { initTelegram } from "@/lib/telegram";

export default function TodayPage() {
  const { targets, today, presets, generateToday, replaceTodayMeal, clearToday } = useApp();
  const [replaceIdx, setReplaceIdx] = useState<number | null>(null);

  useEffect(() => { initTelegram(); }, []);

  const totals = useMemo(() => {
    return today.meals.reduce((acc, m) => {
      const p = getPresetById(presets, m.presetId);
      if (!p) return acc;
      acc.k += p.kcal * m.servings;
      acc.p += p.p * m.servings;
      acc.f += p.f * m.servings;
      acc.c += p.c * m.servings;
      return acc;
    }, {k:0,p:0,f:0,c:0});
  }, [today, presets]);

  return (
    <div>
      <Nav />
      <div className="max-w-4xl mx-auto p-4">
        <div className="card">
          <div className="kpi">
            <div className="chip">Цель: {targets.kcal} ккал</div>
            <div className="chip">Б:{targets.p} Ж:{targets.f} У:{targets.c}</div>
            <div className="chip">Итого: {Math.round(totals.k)} ккал</div>
          </div>
          <div className="mt-3 flex gap-2">
            <button className="btn-primary" onClick={generateToday}>Сгенерировать на день</button>
            <button className="btn-ghost" onClick={clearToday}>Очистить</button>
          </div>
        </div>

        <div className="card">
          <h2 className="mb-2">Сегодняшние приёмы</h2>
          <div className="space-y-2">
            {today.meals.map((m, idx) => {
              const p = getPresetById(presets, m.presetId);
              const budget = p?.kcal ?? (targets.kcal/4);
              const options = presets
                .filter(x => x.type === m.slot && x.kcal <= budget + 50)
                .sort((a,b)=>a.kcal - b.kcal)
                .slice(0, 50);
              return (
                <div key={idx} className="flex items-center justify-between bg-slate-900/40 border border-slate-700/60 rounded-xl p-3 relative">
                  <div>
                    <div className="font-semibold">{m.slot}</div>
                    <div className="text-sm text-muted">{p ? p.name : "— не выбрано —"}</div>
                    <div className="small">ккал: <b>{fmt(p?.kcal)}</b> • Б:{fmt(p?.p,1)} Ж:{fmt(p?.f,1)} У:{fmt(p?.c,1)}</div>
                  </div>
                  <div className="flex gap-2">
                    <button className="btn-ghost" onClick={()=> setReplaceIdx(idx)}>Заменить</button>
                  </div>
                  {replaceIdx === idx && (
                    <div className="absolute left-0 right-0 top-full mt-2 z-10">
                      <div className="card">
                        <div className="flex justify-between items-center mb-2">
                          <div className="font-semibold">Выбери пресет ≤ {Math.round(budget+50)} ккал</div>
                          <button className="btn-ghost" onClick={()=> setReplaceIdx(null)}>Закрыть</button>
                        </div>
                        <div className="grid md:grid-cols-2 gap-2 max-h-[50vh] overflow-y-auto">
                          {options.map(opt => (
                            <div key={opt.id} className="bg-slate-900/70 border border-slate-700/60 rounded-xl p-3">
                              <div className="font-semibold">{opt.name}</div>
                              <div className="small mb-2">ккал:{fmt(opt.kcal)} • Б:{fmt(opt.p,1)} Ж:{fmt(opt.f,1)} У:{fmt(opt.c,1)}</div>
                              <button className="btn-primary" onClick={()=> { replaceTodayMeal(idx, opt.id); setReplaceIdx(null); }}>Выбрать</button>
                            </div>
                          ))}
                          {!options.length && <div className="text-muted">Нет подходящих пресетов для {m.slot}</div>}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
